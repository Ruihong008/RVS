# GENERATED VERSION FILE
__version__ = '1.2.0+2cfb2da'
short_version = '1.2.0'
version_info = (1, 2, 0)
